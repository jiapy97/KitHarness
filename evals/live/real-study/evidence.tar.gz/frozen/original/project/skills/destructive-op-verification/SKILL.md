---
name: destructive-op-verification
description: When archiving, deleting, or retrying a missing receipt.
category: data-integrity
---

Delete or archive a source only after the destination is independently verified to hold its content, and re-run a task after a missing receipt only after confirming the committed state does not already contain the result.

## Rules

- Order: write destination → read back and verify (count, checksum, or content equality) → mark/commit success → remove source. Removal is last and gated.
- A destination that failed earlier in the same batch is not a safe receiver; neither is one that is itself slated for archiving. Require a target that will still exist after the operation.
- A missing receipt is not evidence of failure. Check the committed transaction/log first; if the commit contains the result, close the gap by repairing the receipt — do not redo the work.
- Re-run or rewrite only when the committed state is absent or unverified; re-running a committed operation risks duplicates and lost writes.
- On ambiguity, stop and report rather than deleting: an unarchived source is recoverable, a deleted one is not.

## Pitfalls

- Archiving into a same-batch failure, then deleting the source: content exists nowhere.
- Treating a soon-to-be-archived target as durable storage.
- Re-running a skill on an absent receipt and duplicating already-committed side effects.
- Marking success before the readback confirms the write.
