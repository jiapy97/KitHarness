---
name: utc-date-from-timestamp
description: When deriving a UTC date from timestamps and offsets.
category: data-processing
---

Parse the full timestamp, apply the timezone offset to obtain the instant, then format the date in UTC — never slice the first ten characters of the input string.

## Rules

- Parse into an instant (ISO-8601/RFC-3339 parser, epoch millis, or an equivalent), keeping the offset.
- Convert that instant to UTC, then format only after conversion.
- Never substring the text form: `2026-03-01T00:30:00+09:00` is `2026-02-28` in UTC.
- Test the boundaries explicitly: year rollover (Dec 31/Jan 1), leap day (Feb 29), midnight/day rollover, and offsets that move the instant across midnight.
- Preserve sub-second and offset information until the final format; do not round before converting.

## Pitfalls

- `input[:10]` returns the local date, not the UTC date whenever the offset is non-zero.
- Assuming the offset is `Z`/zero: hosts, logs, and APIs commonly emit local offsets.
- Comparing UTC dates against local end-of-day cutoffs, which shifts the boundary by the offset.
