---
name: resilient-api-consumption
description: Use when paging by cursor or retrying 429s.
category: api-integration
---

Every loop over a remote API ends on an explicit termination condition and is bounded by an attempt or page budget checked *before* the next unit of work is scheduled.

## Cursor pagination

- Only a missing/empty next cursor is a normal end. An empty page with a cursor present means continue, not done.
- Track every cursor requested; a repeated next cursor is a bounded-loop error — stop and surface it.
- De-duplicate across pages by stable record identity, keeping the first occurrence so ordering survives.
- Keep a hard page cap as a backstop and assert on it; a silent stop looks like success.

## Retries and backoff

- Check remaining attempts before computing or appending a wait. A retry that cannot run must not be queued.
- Parse `Retry-After` as seconds (also accept the HTTP-date form) and multiply by 1000 for a millisecond backoff; absolute reset times are compared against the clock, not used as a delay.
- Bound every wait by a max backoff and by the overall deadline, then stop with a surfaced error when the budget runs out.
- Retried operations must be idempotent or keyed so a retry cannot duplicate side effects.

## Pitfalls

- Breaking on an empty item list silently drops every page after it.
- Ignoring a repeated cursor burns quota and memory in an infinite loop.
- Sleeping, then discovering zero attempts remain, blocks for nothing and reports a retry that never happened.
- Feeding seconds into a milliseconds field makes waits 1000x too short, hammering the server.