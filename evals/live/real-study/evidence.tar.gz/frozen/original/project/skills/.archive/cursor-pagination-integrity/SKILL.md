---
name: cursor-pagination-integrity
description: When paging by cursor: empty pages and repeated cursors.
category: api-integration
---

An empty page with a non-empty `next` cursor is not the end — keep paging; terminate on a repeated cursor, and keep the first occurrence of a record seen on multiple pages.

## Rules

- The only normal end condition is a missing/empty next cursor. An empty result page with a cursor present means "continue", not "done".
- Track every cursor you have requested; if the next cursor was already seen, stop immediately and surface a bounded-loop error rather than paging forever.
- De-duplicate across pages by stable record identity, retaining the *first* occurrence so ordering and original position are preserved.
- Keep a hard page cap as a second backstop and assert on it; a silent stop looks like success.

## Pitfalls

- Breaking on an empty item list: silently drops every page after an empty one.
- Ignoring a repeated cursor: infinite loop that burns quota and memory until the process is killed.
- Letting a later duplicate overwrite the first: ordering shifts and the original index is lost.
