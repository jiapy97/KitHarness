---
name: recursive-secret-redaction
description: When redacting tokens in nested JSON config.
category: data-processing
---

Recurse through every object and array, match key names case-insensitively against an explicit target set, and replace only the values of matching keys.

## Rules

- Walk the whole structure: mappings, sequences, and objects nested inside arrays, at any depth.
- Normalize keys before matching — lowercase and strip `-`/`_` separators — then compare against a declared set (`token`, `api_key`, `authorization`, `password`, `secret`, ...).
- Replace the matching *value* (e.g. with a fixed marker), keeping the key and structure intact so configs still load.
- Redact by request/response headers too (e.g. `Authorization`, `Cookie`), not only by JSON body key.
- Never string-replace the word "token" across the document: that mangles business fields such as `token_count` or `tokens_used`.
- Log the count of redactions, never the redacted values.

## Pitfalls

- A top-level-only scan misses secrets nested in lists of objects.
- Case-sensitive matching misses `Token`, `TOKEN`, `accessToken`.
- Blanket substring scrubbing corrupts valid data and changes key names.
