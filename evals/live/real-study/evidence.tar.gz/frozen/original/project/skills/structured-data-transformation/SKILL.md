---
name: structured-data-transformation
description: Use when converting UTC dates or redacting nested secrets.
category: data-processing
---

Parse the payload into a structure, transform the value semantically, and only then serialize — never slice or string-replace the text form.

## Instants to UTC dates

- Parse the full timestamp into an instant, keeping the offset; convert to UTC, then format.
- Never substring the text: `2026-03-01T00:30:00+09:00` is `2026-02-28` in UTC.
- Test boundaries explicitly: year rollover, leap day, midnight rollover, and offsets that cross midnight.
- Preserve sub-second and offset information until the final format; do not round before converting.

## Redacting nested secrets

- Recurse through mappings, sequences, and objects nested inside arrays at any depth.
- Normalize keys (lowercase, strip `-`/`_`) then match a declared set (`token`, `api_key`, `authorization`, `password`, `secret`).
- Replace the matching *value* with a fixed marker, keeping the key and structure intact so configs still load.
- Cover request/response headers too (`Authorization`, `Cookie`), not only JSON body keys.
- Log the count of redactions, never the redacted values.

## Pitfalls

- `input[:10]` returns the local date whenever the offset is non-zero.
- Blanket string-replacing "token" mangles business fields such as `token_count` or `tokens_used`.
- A top-level-only scan misses secrets nested in lists of objects.
- Case-sensitive matching misses `Token`, `TOKEN`, and `accessToken`.