---
name: retry-backoff-budget
description: When HTTP retries hit 429: budget and Retry-After units.
category: api-integration
---

Never schedule a retry once the attempt budget is spent, and convert `Retry-After` from seconds to milliseconds before it enters a millisecond wait array.

## Rules

- Check remaining attempts *before* computing or appending a wait. A retry that cannot run must not be queued.
- Parse `Retry-After` as seconds (also accept the HTTP-date form) and multiply by 1000 for a millisecond backoff; parse absolute reset times against the clock, not as a delay.
- Bound every wait by a max backoff and by the overall deadline/budget, then stop with a surfaced error when the budget runs out.
- Retried operations must be idempotent or keyed so a retry cannot duplicate side effects.

## Pitfalls

- Appending a sleep, then discovering there are zero attempts left: the loop blocks for nothing and reports a retry that never happened.
- Feeding seconds into a milliseconds field: waits are 1000x too short, hammering the server and burning the remaining budget.
- Retrying non-idempotent writes without a key: duplicate records on the server.
